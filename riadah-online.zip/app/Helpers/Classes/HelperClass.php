<?php

class HelperClass{

    public static function printName(){
        return  "Shuvo";
    }
}
