<meta charset="utf-8" />
<title>Dashboard | Codefox - Responsive Admin Dashboard Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
<meta content="Coderthemes" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- App favicon -->
<link rel="shortcut icon" href="{{asset('assets/admin')}}/images/favicon.ico">

<!-- App css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" integrity="sha512-aOG0c6nPNzGk+5zjwyJaoRUgCdOrfSDhmMID2u4+OIslr0GjpLKo7Xm0Ao3xmpM4T8AmIouRkqwj1nrdVsLKEQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="{{asset('assets/admin')}}/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
<link href="{{asset('assets/admin')}}/css/bootstrap-dark.min.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
<!-- tokenfield-->
<link href="{{asset('assets/admin')}}/css/bootstrap-tokenfield.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
<!-- icons -->
<link href="{{asset('assets/admin')}}/css/icons.min.css" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/admin')}}/css/app.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />
<link href="{{asset('assets/admin')}}/css/app-dark.min.css" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />
