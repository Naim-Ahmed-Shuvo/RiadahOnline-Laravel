<link rel="stylesheet" href="{{ asset('assets/web') }}/css/bootstrap.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/all.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/fontawesome.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/style.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/about.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/responsive.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/contact.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/responsice-contact.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/service-main.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/responsive-servicemain.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/details.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/responsive-details.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/partners.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/responsive-partners.css">

@if ($locale=='ar')
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/arabic.css">
@endif
