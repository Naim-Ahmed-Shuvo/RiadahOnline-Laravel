<script src="{{ asset('assets/web') }}/js/jquery-3.3.1.slim.min.js"></script>
<script src="{{ asset('assets/web') }}/js/popper.min.js"></script>
<script src="{{ asset('assets/web') }}/js/bootstrap.min.js"></script>
<script src="{{ asset('assets/web') }}/js/custom.js"></script>
@stack('js')
