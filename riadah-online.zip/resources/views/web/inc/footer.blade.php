<footer>
    <div class="container">
        <div class="row">
            <div class="col">
                <!-- <p>@copyright-2021 . All rights reserved to Riadahonline</p> -->
                <p>@copyright-2021 . All rights reserved to Riadahonline</p>
            </div>
        </div>
    </div>
</footer>