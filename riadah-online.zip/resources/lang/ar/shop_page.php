<?php

return [
    'Shop Page'=>'صفحة تسوق الخدمات',
    'Name'=>'الاسم ',
    'Email'=>'الايميل ',
    'Contact No.'=>'رقم الجوال ',
    'Budget'=>'الميزانية ',
    'Description of Project'=>'وصف المشروع ',
    'Send Request'=>'ارسل طلبك ',
];
