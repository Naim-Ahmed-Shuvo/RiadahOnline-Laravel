<?php

return [
    'Customer Reviews'=>'آراء العملاء',
    'Place Order'=>'قدم طلب',
    'Contact Us'=>'اتصل بنا',
    'Description'=>'الوصف',
    'Contact Us'=>'الوصف',
    'Information'=>'معلومات',
    'Vendor'=>'البائع',
    'Reviews'=>'الآراء',
    'Related Tags'=>'العلامات ذات الصلة'
];
