<?php

return [
   "Search"=>'بحث',
   'Find-the-service-you-need'=>'ابحث عن الخدمة التي تحتاجها',
   'Economic-Consulting'=>'الاستشارات الاقتصادية',
   'Management-Consulting'=>'الاستشارات الادارية',
   'Marketing and Relationships'=>'التسويق والعلاقات',
   'Technology and Information'=>'التكنولوجيا والمعلومات',
   'Investment and Financing'=>'الاستثمار والتمويل',
   'Discovering Leadership'=>'اكتشاف القيادات',
   'Property Management'=>'إدارة الأملاك',
   'Exhibitions and Conferences'=>'المعارض والمؤتمرات',
   'Recruitment and Human Resources'=>'التوظيف والموارد البشرية',
   'Design and Production'=>'التصميم والإنتاج',
   'Commercial Services'=>'خدمات تجارية',
];
