<?php

return [
'Shop Page'=>'صفحة تسوق الخدمات',
'Service Name'=>'اسم الخدمة',
'Number of Orders'=>'عدد الطلبات',
'Duration'=>'المدة',
'Project Price'=>'تكلفة المشروع',
'Service Type'=>'نوع الخدمة',
'Project'=>'بالمشروع',
'Hourly'=>'بالساعة',
'Sub- Total'=>'المجموع الفرعي ',
'VAT'=>'ضريبة القيمة المضافة ',
'Total'=>'الإجمالي ',
'Back to Home'=>'عودة للصفحة الرئيسية ',
'Continue'=>'مواصلة التسوق ',
];
