<?php

return [
    'Congratulations'=>'تهانينا ',
    'Order placed successfully'=>'تم تقديم الطلب بنجاح',
    'Back to buy service'=>'العودة لشراء خدمة',
];
