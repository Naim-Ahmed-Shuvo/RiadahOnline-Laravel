<?php

return [
'Shop Page'=>'Shop Page',
'Service Name'=>'Service Name',
'Number of Orders'=>'Number of Orders',
'Duration'=>'Duration',
'Project Price'=>'Project Price',
'Service Type'=>'Service Type',
'Project'=>'Project',
'Hourly'=>'Hourly',
'Sub- Total'=>'Sub- Total',
'VAT'=>'VAT ',
'Total'=>'Total ',
'Back to Home'=>'Back to Home ',
'Continue'=>'Continue',
];
