<?php

return [
    'Congratulations'=>'Congratulations',
    'Order placed successfully'=>'Order placed successfully',
    'Back to buy service'=>'Back to buy service',
];
