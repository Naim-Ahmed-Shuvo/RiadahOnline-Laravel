<?php

return [
    'Riadah Incubators'=>' Riadah Incubators',
    'Riadah-Incubators-text'=>'Riadah Incubators - Startups Studio and Corporate Factory - The commercial partner to embody your ideas and manage your projects',
    'Economic Incubator'=>'Economic Incubator',
    'Economic-Incubator-text'=>'Economic Incubator for economic and administrative consultancy and feasibility studies',
    'Discovering Leadership'=>'Discovering Leadership' ,
    'Discovering-Leadership-text'=>'Discovering Leadership for developing and qualifying cadres and preparing organizational and administrative structures',
    'Event Incubators'=>'Event Incubators',
    'Event-Incubators-text'=>'Event Incubator for marketing events and attracting international exhibitions
    - Job Incubator for search, recruitment and interviewing',
    'Job Incubators'=>'Job Incubators',
    'Job-Incubators-text'=>'Job Incubator for search, recruitment and interviewing',
    'Marketing Incubators'=>'Marketing Incubators',
    'Marketing-Incubators-text'=>'Marketing Incubator for marketing consulting, managing advertising campaigns and developing marketing plans',
    'Technical Incubator'=>'Technical Incubator',
    'Technical-Incubator-text'=>'Technical Incubator for Cloud computing, artificial intelligence, ERP system design, hotel and hospital management software',
    'Data Incubator'=>'Data Incubator',
    'Data-Incubator-text'=>'Data Incubator for the establishment and management of business support and data market observatories',
    'text-1'=>'Riadah Incubators - Startups Studio and Corporate Factory - The commercial partner to embody your ideas and manage your projects',
    'text-2'=>'Economic Incubator Economic consulting includes the study of macro and micro economics',
    'text-3'=>'Management consulting incubator, which includes strategic planning, quality systems and research',
    'text-4'=>'The Leadership Discovery Center includes recruitment, training and human capital management',
    'text-5'=>'Relationships incubator, including marketing, social responsibility programs, and media center management',
    'text-6'=>'Technology incubator includes the establishment of technology projects and includes designing websites and applications',
    'text-7'=>'The investment incubator includes financing, consolidating financial culture and building relationships with investment agencies',
    'text-8'=>'Economic Incubator for economic and administrative consultancy and feasibility studies',
    'text-9'=>'Media incubator, including publishing, managing media centers, and IPTV broadcasting',
    'text-10'=>'Employment incubator, including mediation, and transforming societies from pastoral to developmental',
    'text-11'=>'Property incubator, which includes property management for the commercial and industrial sector, asset rental and brokerage',
    'text-12'=>'Leadership Discovery Academy, which aims to provide specializations related to future jobs',
    'text-13'=>'Events incubator Holding many exhibitions and conferences locally and internationally and marketing sponsorships'
];
