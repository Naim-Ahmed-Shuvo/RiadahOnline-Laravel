<?php

return [
    'Customer Reviews'=>'Customer Reviews',
    'Place Order'=>'Place Order',
    'Contact Us'=>'Contact Us',
    'Description'=>'Description',
    'Contact Us'=>'Contact Us',
    'Information'=>'Information',
    'Vendor'=>'Vendor',
    'Reviews'=>'Reviews',
];
