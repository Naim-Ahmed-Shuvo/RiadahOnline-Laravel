<?php

return [
   "Search"=>'Search',
   'Find-the-service-you-need'=>'Find-the-service-you-need',
   'Economic-Consulting'=>'Economic Consulting',
   'Management-Consulting'=>'Management-Consulting',
   'Marketing and Relationships'=>'Marketing and Relationships',
   'Technology and Information'=>'Technology and Information',
   'Investment and Financing'=>'Investment and Financing',
   'Discovering Leadership'=>'Discovering Leadership',
   'Property Management'=>'Property Management',
   'Exhibitions and Conferences'=>'Exhibitions and Conferences',
   'Recruitment and Human Resources'=>'Recruitment and Human Resources',
   'Design and Production'=>'Design and Productio',
   'Commercial Services'=>'Commercial Services',
];
