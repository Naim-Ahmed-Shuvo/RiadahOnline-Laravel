<?php

return [
    'Contact Us'=>'Contact Us',
    'Call Us'=>'Call Us',
    'call-us-text'=>'We are always happy to answer your inquiries and talk with business people about ways in which we can work together to improve business performance. Our doors are open to everyone, welcome to you',
    'mobile'=>' 0551175959',
    'email'=>'info@riadahonline.com',
    'Our Office'=>'Our Office',
    'office address'=>'Address: Riadah Incubators Startup Studio And corporate factory - Khaldiya Towers - 4th Tower - Faisal Bin Turki Road - Office No. 6 - Floor 13 – Riyadh',

    // form
    'contact-form-top-text'=>'We hope that you will fill out this form and we will be happy to serve you to the fullest',
    'Name'=>'Name',
    'Email Address'=>'Email Address',
    'Your Phone'=>'Your Phone',
    'Your city'=>'Your city',
    'Send Message'=>'Send Message'
];
