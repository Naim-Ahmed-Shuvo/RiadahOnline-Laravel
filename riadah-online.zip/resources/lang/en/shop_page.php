<?php

return [
    'Shop Page'=>'Shop Page',
    'Name'=>'Name',
    'Email'=>'Email',
    'Contact No.'=>'Contact No.',
    'Budget'=>'Budget',
    'Description of Project'=>'Description of Project',
    'Send Request'=>'Send Request',
];
